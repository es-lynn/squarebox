import { server } from './src/app/App'

server.listen(4000)

console.info('Server started')
