export const _200_OKAY = 200
export const _204_NO_CONTENT = 204
export const _400_CLIENT_ERROR = 400
export const _409_CONFLICT = 409
export const _500_SERVER_ERROR = 500
